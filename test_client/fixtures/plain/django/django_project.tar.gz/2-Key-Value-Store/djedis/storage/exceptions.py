class UserDoesNotExist(Exception):
    pass
